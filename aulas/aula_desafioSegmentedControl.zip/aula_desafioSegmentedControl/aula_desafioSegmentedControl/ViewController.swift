//
//  ViewController.swift
//  aula_desafioSegmentedControl
//
//  Created by Jessica Arruda Ferreira de Santana on 13/09/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usuariosTableView: UITableView!
    @IBOutlet weak var usuariosSegmentedControl: UISegmentedControl!
    
    var usuarios: [Usuario] = [
        .init(nome: "João"),
        .init(nome: "Laura"),
        .init(nome: "José"),
        .init(nome: "Carlos"),
        .init(nome: "Pedro"),
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        usuariosTableView.dataSource = self
        usuariosTableView.delegate = self
    }

    @IBAction func mySegmentedControl(_ sender: Any) {
        switch usuariosSegmentedControl.selectedSegmentIndex {
        case 0:
            mudarParaImagem(ehProgramador: true)
        case 1:
            mudarParaImagem(ehProgramador: false)
        default:
            break
        }
    }
    
    func mudarParaImagem(ehProgramador: Bool) {
        for usuario in usuarios {
            if ehProgramador {
                usuario.imagem = "programador.jpeg"
            } else {
                usuario.imagem = "pessoa.jpeg"
            }
        }
        usuariosTableView.reloadData()
    }
}

extension ViewController: UITableViewDelegate {}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usuarios.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                
        if let cell = tableView.dequeueReusableCell(withIdentifier: "usuarioTableViewCell", for: indexPath) as? UsuarioTableViewCell {
            
            cell.setup(usuario: usuarios[indexPath.row])
            
            return cell
            
        }
        
        
        
        return UITableViewCell()
    }
}

