//
//  Usuario.swift
//  aula_desafioSegmentedControl
//
//  Created by Jessica Arruda Ferreira de Santana on 13/09/21.
//

import Foundation

class Usuario {
    let nome: String
    var imagem: String
        
    init(nome: String) {
        self.nome = nome
        self.imagem = "programador.jpeg"
    }
}
