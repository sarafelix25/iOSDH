//
//  ViewController.swift
//  aula_tabbarCorrecao
//
//  Created by Jessica Arruda Ferreira de Santana on 20/09/21.
//

import UIKit

class SomaViewController: UIViewController {
    @IBOutlet weak var resultadoLabel: UILabel!
   
    @IBOutlet weak var valorATextField: UITextField!
    @IBOutlet weak var valorBTextField: UITextField!
    
    let calculadora: Calculadora = Calculadora()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func somaButtonAction(_ sender: Any) {
        realizaSomaEntreTextFields(valorATextField, valorBTextField)
    }
    
    private func realizaSomaEntreTextFields(_ textFieldA: UITextField, _ textFieldB: UITextField) {
        
        if ehValido(textField: textFieldA) && ehValido(textField: textFieldB) {
            let valorA = converteStringParaNumero(string: textFieldA.text)
            let valorB = converteStringParaNumero(string: textFieldB.text)
            
            let resultado = calculadora.soma(valorA: valorA, valorB: valorB)
            
            resultadoLabel.text = "\(resultado)"
        }
    }
    
    private func converteStringParaNumero(string: String?) -> Int { // numero1 ?? 0
        guard let string = string, let numero = Int(string) else { return 0 }
        return numero
    }
    
    private func ehValido(textField: UITextField) -> Bool {

        guard let valor = textField.text, let _ = Int(valor) else {
            adicionaModeloErroA(textField: textField)
            return false
        }
        
        removeModeloErroSeNecessarioA(textField: textField)
        return true
    }
    
    private func adicionaModeloErroA(textField: UITextField) {
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.red.cgColor
    }
    
    private func removeModeloErroSeNecessarioA(textField: UITextField) {
        if textField.layer.borderColor == UIColor.red.cgColor {
            textField.layer.borderColor = UIColor.clear.cgColor
        }
    }
    
    //    private func soma() {
    //        let numero1 = Int(valorATextField.text!)
    //        let numero2 = Int(valorBTextField.text!)
    //
    //        resultadoLabel.text = String((numero1 ?? 0)  + (numero2 ?? 0))
    //    }
    
}

