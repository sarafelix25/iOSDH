//
//  Calculadora.swift
//  aula_tabbarCorrecao
//
//  Created by Jessica Arruda Ferreira de Santana on 20/09/21.
//

import Foundation

class Calculadora {
    func soma(valorA: Int, valorB: Int) -> Int {
        return valorA + valorB
    }
    
    func subtracao(valorA: Int, valorB: Int) -> Int {
        return valorA - valorB
    }
}
