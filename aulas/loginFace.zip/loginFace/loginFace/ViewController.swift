//
//  ViewController.swift
//  loginFace
//
//  Created by Sara on 01/12/21.
//

import UIKit
import FacebookCore
import FacebookLogin
import FirebaseAuth

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let loginButton = FBLoginButton(frame: .zero, permissions: [.publicProfile])
        loginButton.center = view.center
        loginButton.delegate = self
        
        self.view.addSubview(loginButton)
        
        if let acessToken = AccessToken.current {
            print("<<<<<usuário já logado")
            print(acessToken)
        }
    }
    
    func loginFacebookNoFirebase(acessToken: String) {
        
        let credential = FacebookAuthProvider.credential(withAccessToken: acessToken)
        
        Auth.auth().signIn(with: credential) { result, error in
            if let error = error {
                print("Deu erro ao logar no firebase")
            }
            
            print("Usuário efetuou login no firebase")
            print(result)
            
            if let user = Auth.auth().currentUser {
                print("O usuário do firebase é: \(user)")
            }
        }
    }
}

extension ViewController: LoginButtonDelegate {
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        print("<<<<<usuário já efetuou login")
        
        switch result {
            
        case .none:
            print("um erro aconteceu")
        case .some(let loginResult):
            print(loginResult.grantedPermissions)
            print(loginResult.declinedPermissions)
            print(loginResult.isCancelled)
            print(loginResult.token)
            
            if let token = loginResult.token?.tokenString {
                loginFacebookNoFirebase(acessToken: token)
            }
        }
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        print("<<<<<usuário efetuou logout")
    }
}
