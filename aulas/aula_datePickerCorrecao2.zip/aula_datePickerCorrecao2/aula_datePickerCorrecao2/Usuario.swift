//
//  Usuario.swift
//  aula_datePickerCorrecao2
//
//  Created by Jessica Arruda Ferreira de Santana on 15/09/21.
//

import Foundation

class Usuario {
    let nome: String
    var imagem: String = ""
    var date: Date
    
    init(nome: String, date: Date) {
        self.nome = nome
        self.date = date
        self.imagem = defineImagemAPartirDe(date: date)
    }
    
    public func defineImagemAPartirDe(date: Date) -> String {
        let dataAtual = Date() // 15/09
        let resultadoComparacao: ComparisonResult = compareDates(dataAtual, date)
        
        if resultadoComparacao == .orderedDescending { // passado
            return "pessoa.jpeg"
            // imagem de pessoa
        }
        
        if resultadoComparacao == .orderedAscending { // futuro
            return "programador.jpeg"
            // imagem de programador
        }
        
        if resultadoComparacao == .orderedSame { // presente
            return "black.jpeg"
            // imagem preta
        }
        return ""
    }
    
    
    private func compareDates(_ dataAtual: Date, _ dateSelecionadaPorUsuario: Date) -> ComparisonResult {
        
        return Calendar.current.compare(dataAtual, to: dateSelecionadaPorUsuario, toGranularity: .day)
    }
}
