//
//  DatePickerTableViewCell.swift
//  aula_datePickerCorrecao2
//
//  Created by Jessica Arruda Ferreira de Santana on 15/09/21.
//

import UIKit

class DatePickerTableViewCell: UITableViewCell {

    @IBOutlet weak var datePickerImageView: UIImageView!
    @IBOutlet weak var datePickerLabel: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var usuario: Usuario!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setup(usuario: Usuario) {
        self.usuario = usuario
        
        datePickerLabel.text = usuario.nome
        datePickerImageView.image = UIImage(named: usuario.imagem)
        datePicker.date = usuario.date
    }

    @IBAction func datePickerMudouValor(_ sender: Any) {
        let dataSelecionadaPeloUsuario = datePicker.date
        
        let novaImagem = usuario.defineImagemAPartirDe(date: dataSelecionadaPeloUsuario)
        datePickerImageView.image = UIImage(named: novaImagem)
    }
}
