//
//  ViewController.swift
//  aula_datePickerCorrecao2
//
//  Created by Jessica Arruda Ferreira de Santana on 15/09/21.
//

import UIKit

class ViewController: UIViewController {
    
    var usuarios: [Usuario] = [
        .init(nome: "Jessica", date: Date()),
        .init(nome: "Adriano", date: Date()),
        .init(nome: "Guilherme", date: Date()),
    ]

    @IBOutlet weak var usuariosTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        usuariosTableView.delegate = self
        usuariosTableView.dataSource = self
    }
    
    private func generateDate(stringDate: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let someDateTime = formatter.date(from: stringDate)
        return someDateTime ?? Date()
    }
    
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usuarios.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "datePickerTableViewCell", for: indexPath) as? DatePickerTableViewCell {
            
            cell.setup(usuario: usuarios[indexPath.row])
            
            return cell
            
        }
        return UITableViewCell()
    }
}


