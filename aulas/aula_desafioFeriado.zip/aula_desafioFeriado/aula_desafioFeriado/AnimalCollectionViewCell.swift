//
//  CategoriaAnimalCollectionViewCell.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

import UIKit

class AnimalCollectionViewCell: UICollectionViewCell {
    @IBOutlet var categoriaAnimalImageView: UIImageView!
    @IBOutlet var nomeCategoriaAnimal: UILabel!
    
    func setup(_ animal: Animal){
        categoriaAnimalImageView.image = UIImage(named:animal.imagem)
        nomeCategoriaAnimal.text = animal.nome
    }
    
    
}
