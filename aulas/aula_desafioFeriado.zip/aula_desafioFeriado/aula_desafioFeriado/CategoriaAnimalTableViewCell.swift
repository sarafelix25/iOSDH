//
//  AnimalTableViewCell.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

import UIKit

class CategoriaAnimalTableViewCell: UITableViewCell {
    
    @IBOutlet var categoriaAnimalImageView: UIImageView!
    @IBOutlet var nomeCategoriaAnimal: UILabel!


    func setup(_ categoriaAnimal: CategoriaAnimal){
        nomeCategoriaAnimal.text = categoriaAnimal.nomeClasse
        categoriaAnimalImageView.image = UIImage(named: categoriaAnimal.imagemClasse)
    }

}
