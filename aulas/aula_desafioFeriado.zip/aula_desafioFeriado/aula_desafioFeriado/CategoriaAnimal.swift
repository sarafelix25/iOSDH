//
//  Animal.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

import Foundation

class CategoriaAnimal {
    let nomeClasse: String
    let imagemClasse: String
    
    init(nomeClasse: String, imagemClasse: String) {
        self.nomeClasse = nomeClasse
        self.imagemClasse = imagemClasse
    }
}
