//
//  AnimalViewController.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

import UIKit

class AnimalViewController: UIViewController {
    
    @IBOutlet weak var animalsCollectionView: UICollectionView!
    
    var tituloAnimal: String = ""
    var animals: [Animal] = []
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = tituloAnimal
        setupAnimalsList(categoriaAnimal: tituloAnimal)
        super.viewWillAppear(true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.animalsCollectionView.dataSource = self
        self.animalsCollectionView.delegate = self
    }
    
    func setupAnimalsList(categoriaAnimal: String){
        switch categoriaAnimal {
        case "Peixes":
            carregaArrayPeixes()
        case "Anfíbios":
            carregaArrayAnfibios()
        case "Répteis":
            carregaArrayRepteis()
        case "Aves":
            carregaArrayAves()
        case "Mamíferos":
            carregaArrayMamiferos()
        default:
            animals = []
        }
    }
    
    func carregaArrayPeixes(){
        let peixes: [Animal] = [
            .init(nome: "Enguia", imagem: "enguia.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "Parece uma cobra"),
            .init(nome: "Peixe-Palhaço", imagem: "peixepalhaco.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "Aparece no filme Procurando Nemo"),
            .init(nome: "Tang Azul", imagem: "tangazul.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "Aparece no filme Procurando Nemo"),
            .init(nome: "Peixe-Dourado", imagem: "peixedourado.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "Aparece no filme Pinóquio"),
            .init(nome: "Peixe-Anjo-Real", imagem: "peixeanjoreal.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "Aparece no filme A Pequena Sereia"),
            .init(nome: "Bodião-limpador", imagem: "bodiaolimpador.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "Aparece no filme O Espanta Tubarões"),
            .init(nome: "Pangasius", imagem: "Pangasius.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "É utilizado na alimentação"),
            .init(nome: "Polaca", imagem: "Polaca.png", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "É utilizado na alimentação"),
            .init(nome: "Tilápia", imagem: "Tilapia.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "É utilizado na alimentação"),
            .init(nome: "Linguado", imagem: "Linguado.jpeg", nomeClasse: "Peixe", imagemClasse: "peixe.png", curiosidade: "É utilizado na alimentação"),
        ]
        
        self.animals = peixes
        
    }
    
    func carregaArrayAnfibios(){
        let anfibios: [Animal] = [
            .init(nome: "Cecília-mexicana", imagem: "ceciliamexicana.jpeg", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: ""),
            .init(nome: "Cecília-de-Koh-Tao", imagem: "ceiciliakoh", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "é uma cecília tailandesa que bota seus ovos no chão. Ao contrário da maioria dos anfíbios, a mãe cuida dos ovos até que eclodam."),
            .init(nome: "Anfiumas", imagem: "Anfiumas.jpeg", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "são três espécies de anfíbios aquáticos muito alongados, cilíndricos e com pernas vestigiais. A. tridactylum possui três dedos, A. means possui dois e A. pholeter possui apenas um. Apesar de sua aparência, eles não são cecílias, e sim urodelos."),
            .init(nome: "Proteus", imagem: "proteus.jpeg", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "este urodelo é adaptado para viver na escuridão de algumas cavernas européias. Por esse motivo, os adultos não têm olhos, são brancos ou rosados ​​e vivem na água durante toda a vida. Além disso, são alongados, têm a cabeça plana e respiram através de brânquias."),
            .init(nome: "Salamandra-de-costelas-salientes", imagem: "salamandracostelas.jpeg", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "é um urodelo europeu que pode atingir 30 centímetros de comprimento. Na lateral de seu corpo, há uma fileira de manchas alaranjadas que coincidem com as bordas das costelas. Quando se sentem ameaçados, eles as destacam, ameaçando seus predadores em potencial."),
            .init(nome: "Rã-peluda", imagem: "rapeluda", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "apesar de sua aparência, as rãs peludas não possuem pelos, e sim extensões de pele vascularizada. Elas servem para aumentar a superfície das trocas gasosas, de maneira que é possível absorver mais oxigênio."),
            .init(nome: "Sapo-do-Surinã", imagem: "saposurina.jpeg", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "este sapo da Amazônia é caracterizado por ter um corpo extremamente achatado. As fêmeas têm um tipo de rede nas costas, na qual afundam e prendem os ovos durante a cópula. Desses ovos, emergem não larvas, mas sapos jovens."),
            .init(nome: "Sapo-do-monte-Nimba", imagem: "saponimba.jpeg", nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg", curiosidade: "é um sapo africano vivíparo. As fêmeas dão luz a crias com a mesma aparência de um adulto. O desenvolvimento direto é uma estratégia reprodutiva que lhes permite ser independentes dos corpos d'água."),

        ]
        
        self.animals = anfibios
        
    }

    func carregaArrayRepteis(){
        let repteis: [Animal] = [
            .init(nome: "Tartaruga", imagem: "Tartaruga.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Jabuti", imagem: "Jabuti.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Cágado", imagem: "Cagado.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Cobra", imagem: "Cobra.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Serpente", imagem: "Serpente.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Jacaré", imagem: "Jacare.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Crocodilo", imagem: "Crocodilo.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Camaleão", imagem: "Camaleao.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Iguana", imagem: "Iguana.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Lagarto", imagem: "Lagarto.jpeg", nomeClasse: "Répteis", imagemClasse: "Répteis.png", curiosidade: "Sou curiosa!"),
        ]
        
        self.animals = repteis
        
    }

    func carregaArrayAves(){
        let aves: [Animal] = [
            .init(nome: "Papagaio", imagem: "Papagaio.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "O papagaio-verdadeiro é principalmente um papagaio verde com cerca de 38 cm (quinze polegadas) de comprimento e pesa cerca de quatrocentos gramas. Tem penas azuis na testa, acima do bico e amarelo na cara e coroa. Distribuição do azul e amarelo varia muito. A cor da íris dos adultos é amarelo-laranja no macho ou vermelho-laranja na fêmea. Se destaca um fino anel externo vermelho. Os imaturos têm íris marrom uniforme. O bico é negro no macho adulto. É uma das espécies mais inteligentes de ave do planeta. Sua expectativa de vida é de oitenta anos. Os papagaios-verdadeiros também costumam repetir o que ouvem de seus donos."),
            .init(nome: "Arara azul", imagem: "Araraazul.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "A arara-azul-grande (Anodorhynchus hyacinthinus), também chamada arara-jacinto, araraúna, arara-preta, araruna, ou simplesmente arara-azulé uma ave da família Psittacidae que vive nos biomas da Floresta Amazônica e principalmente noCerrado e Pantanal. Está ameaçada deextinção, tal como a arara-azul-de-lear(Anodorhychuns leari) e como a arara-azul-pequena (Anodorhychuns glaucus) considerada extinta no Brasil. Possui uma plumagem azul com uma pele nua amarela em torno dos olhos e fita da mesma cor na base da mandíbula. Seu bico é desmesurado, parecendo ser maior que o próprio crânio. Sua alimentação, enquanto vivendo livremente, consiste de sementes de palmeiras (cocos), especialmente olicuri."),
            .init(nome: "Avestruz", imagem: "Avestruz.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "O avestruz (Struthio camelus) é uma ave não voadora, originária da África. É a única espécie viva da famíliaStruthionidae, do género Struthio e da ordem das Struthioniformes. São considerados a maior espécie viva de ave."),
            .init(nome: "Galinha", imagem: "Galinha.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "Estas aves possuem bico pequeno,crista carnuda, pernas escamosas easas curtas e largas. A galinha tem uma enorme importância para o homem, sendo o animal doméstico mais difundido e abundante doplaneta e uma das fontes de proteínamais baratas. Além de sua carne, as galinhas fornecem ovos. As penas também têm utilizações industriais. Segundo dados de 2003, há cerca de 24000 milhões de galinhas no mundo. Em alguns países da África moderna, 90% dos lares criam galinhas. As galinhas são aves omnívoras, tendo preferência por sementes e pequenosinvertebrados."),
            .init(nome: "Pombo", imagem: "Pombo.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "Verifica-se grande variação no padrão de cores desse animal, havendo exemplares brancos, marrons, manchados e acinzentados. Há poucas diferenças visíveis entre machos e fêmeas. Sua plumagem é normalmente em tons cinza, mais claro nas asas que no peito e cabeça, com cauda riscada de negro epescoço esverdeado. Caracterizam-se, em geral, pelos reflexos metálicos na plumagem, cabeça e pés pequenos ebico com elevação na base, sendo a ponta deste em forma de gancho, costumando ser negro, curto e fino, com 3,8 cm de comprimento médio. Geralmente são monogâmicos, tendo dois filhotes por ninhada. Ambos os pais cuidam do filhote por um tempo."),
            .init(nome: "Pavão", imagem: "Pavao.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "Chama-se pavão a aves dos génerosPavo e Afropavo da família dos faisões (Phasianidae). Os pavões preferem alimentar-se de insetos e outros pequenos invertebrados, mas também comem sementes, insetos, frutas e outros itens nutritivos que estão disponíveis rapidamente. Os pavões exibem um complicado ritual de acasalamento, do qual a caudaextravagante do macho teria um papel principal. As características da cauda colorida, que chega a ter dois metros de comprimento e pode ser aberta como um leque, não têm qualquer utilidade quotidiana para o animal e seriam um exemplo de seleção sexual. Quando o processo é bem sucedido, a pavoa põe entre 4 a 8 ovos, que chocam ao fim de 28 dias."),
            .init(nome: "Águia", imagem: "Aguia.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "A águia é o nome comum dado algumas aves de rapina da famíliaAccipitridae, geralmente de grande porte, carnívoras, de grande acuidade visual. O nome é atribuído a animais pertencentes a gêneros diversos e não corresponde a nenhuma cladetaxonômica. Por vezes, dentro de um mesmo gênero ocorrem espéciesconhecidas popularmente por gaviãoou búteo. Suas principais presas são: coelhos, esquilos, cobras, marmotas e outros animais, principalmente roedores, de pequeno porte. Algumas espécies alimentam-se de ovos de outros pássaros e peixes."),
            .init(nome: "Gavião", imagem: "Gaviao.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "Gavião é o nome popular dado a várias espécies de aves falconiformespertencentes às famílias Accipitridae eFalconidae, em particular dos gênerosLeucopternis, Buteo e Buteogallus. São aves geralmente identificadas pelo tamanho, de médio a pequeno porte, em relação a outras aves de rapina. Dotadas de asas curtas, são adaptadas à predação em espaços fechados. Esta designação não corresponde a nenhuma classe taxonômica e pode acontecer que dentro do mesmo gênero haja espécies chamadas gavião e outras com o nome de águia. De uma forma geral, os gaviões têm uma distribuição bastante vasta, que inclui todos os continentes com exceção daAntártida."),
            .init(nome: "Tucano", imagem: "Tucano.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "São designadas por tucano as aves da família Ramphastidae que vivem nas florestas da América Central eAmérica do Sul. Possuem um bico grande e oco. A parte superior é constituída por trabéculas de sustentação e a parte inferior é de natureza óssea. Não é um bico forte, já que é muito comprido e a alavanca, (maxilar) não é suficiente para conferir tal qualidade. Seu sistema digestivo é extremamente curto, o que explica a sua base alimentar, já que as frutas são facilmente digeridas e absorvidas pelo trato gastrointestinal."),
            .init(nome: "Pinguins", imagem: "Pinguins.jpeg", nomeClasse: "Aves", imagemClasse: "Aves.png", curiosidade: "O pinguim (RO 1971: pingüim) é uma ave da família Spheniscidae, característica do Hemisfério Sul, em especial na Antártida e ilhas dos mares austrais, chegado à Terra do Fogo, Ilhas Malvinas e África do Sul, entre outros. Apesar da maior diversidade de pinguins encontrar-se na Antártida e regiões polares, há também espécies que habitam nos trópicos como por exemplo o pinguim-das-galápagos. A morfologia dos pinguins reflete várias adaptações à vida no meio aquático: o corpo é fusiforme; as asas atrofiadas desempenham a função debarbatanas e as pele são impermeabilizadas através da secreção de óleos. Os pinguins alimentam-se de pequenos peixes, krille outras formas de vida marinha, sendo por sua vez vítimas da predação de orcas e focas-leopardo."),
        ]
        
        self.animals = aves
    }

    func carregaArrayMamiferos(){
        let mamiferos: [Animal] = [
            .init(nome: "Gato", imagem: "Gato.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Cachorro", imagem: "Cachorro.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Girafa", imagem: "Girafa.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Leão", imagem: "leao.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Anta", imagem: "Anta.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Onça", imagem: "Onca.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Leopardo", imagem: "Leopardo.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Lontra", imagem: "Lontra.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Camelo", imagem: "Camelo.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
            .init(nome: "Alpaca", imagem: "Alpaca.jpeg", nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png", curiosidade: "Sou curiosa!"),
        ]
        
        self.animals = mamiferos
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToDetail" {
            let animal = sender as? Animal
            if let detalheViewController = segue.destination as? DetalheAnimalViewController {
                detalheViewController.animal = animal
            }
        }
    }

}

extension AnimalViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "goToDetail", sender: animals[indexPath.row])
    }
}

extension AnimalViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return animals.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "animalCollectionViewCell", for: indexPath) as? AnimalCollectionViewCell {
            cell.setup(animals[indexPath.row])
            return cell
        }
        
        return UICollectionViewCell()
    }
    
}
