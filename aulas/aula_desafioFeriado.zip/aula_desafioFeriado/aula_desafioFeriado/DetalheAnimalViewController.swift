//
//  DetalheAnimalViewController.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

import UIKit

class DetalheAnimalViewController: UIViewController {
    @IBOutlet weak var animalImageView: UIImageView!
    @IBOutlet weak var nomeAnimalLabel: UILabel!
    @IBOutlet weak var curiosidadeAnimal: UITextView!
    
    
    var animal: Animal?
    
    override func viewWillAppear(_ animated: Bool) {
        carregaInformacoesAnimal()
        super.viewWillAppear(true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func carregaInformacoesAnimal() {
        animalImageView.image = UIImage(named: animal?.imagem ?? "")
        nomeAnimalLabel.text = animal?.nome
        curiosidadeAnimal.text = animal?.curiosidade
    }
    
    @IBAction func fecharBotaAcao(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
