//
//  Animal.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

class Animal: CategoriaAnimal {
    let nome: String
    let imagem: String
    let curiosidade: String
    
    init(nome: String, imagem: String, nomeClasse: String, imagemClasse: String, curiosidade: String) {
        self.nome = nome
        self.imagem = imagem
        self.curiosidade = curiosidade
        super.init(nomeClasse: nomeClasse, imagemClasse: imagemClasse)
    }
}
