//
//  ViewController.swift
//  aula_desafioFeriado
//
//  Created by Jessica Arruda Ferreira de Santana on 08/09/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var animalsTableView: UITableView!
    
    var categoriaAnimais: [CategoriaAnimal] = [
        CategoriaAnimal(nomeClasse: "Peixes", imagemClasse: "peixe.png"),
        .init(nomeClasse: "Anfíbios", imagemClasse: "Anfíbio.jpeg"),
        .init(nomeClasse: "Répteis", imagemClasse: "Répteis.png"),
        .init(nomeClasse: "Aves", imagemClasse: "Aves.png"),
        .init(nomeClasse: "Mamíferos", imagemClasse: "Mamífero.png")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        animalsTableView.dataSource = self
        animalsTableView.delegate = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToTipoAnimal" {
            let cell = sender as? CategoriaAnimalTableViewCell
            if let animalViewController = segue.destination as? AnimalViewController {
                animalViewController.tituloAnimal = cell?.nomeCategoriaAnimal.text ?? ""
            }
        }
    }


}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categoriaAnimais.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "animalCell", for: indexPath) as? CategoriaAnimalTableViewCell {
            
            
            
            cell.setup(categoriaAnimais[indexPath.row])
            
            
            return cell
        }
        
        return UITableViewCell()
    }
    
    
}

