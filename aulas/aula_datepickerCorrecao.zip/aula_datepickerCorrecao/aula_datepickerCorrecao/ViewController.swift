//
//  ViewController.swift
//  aula_datepickerCorrecao
//
//  Created by Jessica Arruda Ferreira de Santana on 15/09/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nomeTextField: UITextField!
    @IBOutlet weak var telefoneTextField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var nomeLabel: UILabel!
    @IBOutlet weak var telefoneLabel: UILabel!
    @IBOutlet weak var dataLabel: UILabel!
    
    var dateFormatter: DateFormatter!
    
    override func viewDidLoad() {
        dateFormatter = configuraFormatadorDeDataEmPortugues()
        super.viewDidLoad()
    }

    @IBAction func datePickerMudouValor(_ sender: Any) {
        let stringDate = dateFormatter.string(from: datePicker.date)
        atribuiTextoParaLabel(date: stringDate)
    }
    
    private func atribuiTextoParaLabel(date: String) {
        nomeLabel.text = nomeTextField.text
        telefoneLabel.text = telefoneTextField.text
        dataLabel.text = date
    }
    
    private func configuraFormatadorDeDataEmPortugues() -> DateFormatter {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.short
        dateFormatter.timeStyle = DateFormatter.Style.short
        dateFormatter.locale = Locale(identifier: "PT_BR")
        
        return dateFormatter
    }
    
}

